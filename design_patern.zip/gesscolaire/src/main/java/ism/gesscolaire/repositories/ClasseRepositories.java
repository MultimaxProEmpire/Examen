package ism.gesscolaire.repositories;
import ism.gesscolaire.entities.Classe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClasseRepositories extends JpaRepository<Classe,Long> {
    Classe findByLibelle(String libelle);

}
