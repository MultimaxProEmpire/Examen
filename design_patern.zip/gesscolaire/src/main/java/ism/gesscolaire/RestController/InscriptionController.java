package ism.gesscolaire.RestController;


import ism.gesscolaire.entities.Classe;
import ism.gesscolaire.entities.Etudiants;
import ism.gesscolaire.repositories.ClasseRepositories;
import ism.gesscolaire.repositories.EtudiantRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/inscription")
public class InscriptionController {
    @Autowired
    private EtudiantRepositories etudiantsRepository;
    @Autowired
    private ClasseRepositories classeRepositories;
    @GetMapping
    public List<Etudiants> getAllEtudiants() {
        return etudiantsRepository.findAll();
    }


    @GetMapping("/{classe}")
    public List<Etudiants> getEtudiantById(@PathVariable String classe) {
       Classe classe1 = classeRepositories.findByLibelle(classe);
        return etudiantsRepository.findByClasse(classe1);
    }
}
