package ism.gesscolaire.entities;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;


@Entity
@Table(name="etudiant")
@Data
@Setter
@Getter
public class Etudiants {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(nullable = false)
    private String nomComplet;
    @Column(nullable = false)
    private String tuteur;
    @Column(nullable = false)
    private LocalDate dateInscription;
    @Column(nullable = false)
    private String email;
    @Column(nullable = false)
    private String password;

    @ManyToOne
    @JoinColumn(name = "classe_id")
    private Classe classe;




}
